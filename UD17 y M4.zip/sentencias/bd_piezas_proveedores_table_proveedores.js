use bd_piezas_proveedores

db.proveedores.insertMany([



{_id:'0001',nombre: "Proveedor 1"},
{_id:'0002',nombre: "Proveedor 2"},
{_id:'0003',nombre: "Proveedor 3"},
{_id:'0004',nombre: "Proveedor 4"},
{_id:'0005',nombre: "Proveedor 5"},
{_id:'0006',nombre: "Proveedor 6"},
{_id:'0007',nombre: "Proveedor 7"},
{_id:'0008',nombre: "Proveedor 8"},
{_id:'0009',nombre: "Proveedor 9"},
{_id:'0010',nombre: "Proveedor 10"}

]);

db.proveedores.find()