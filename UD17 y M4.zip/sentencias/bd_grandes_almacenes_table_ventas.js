use bd_grandes_almacenes

db.ventas.insertMany([



{cajero:'Alberto Zambrano',maquina:1, producto:'zapatos'},
{cajero:'Luis Perez',maquina:2, producto:'camisetas'},
{cajero:'Ana Fernandez',maquina:3, producto:'pantalones'},
{cajero:'Raul Farfan',maquina:4, producto:'gorras'},
{cajero:'Jose Lito',maquina:5, producto:'chanclas'},
{cajero:'Carlos Latre',maquina:6, producto:'collares'},
{cajero:'Kimberly Alvarez',maquina:7, producto:'gafas'},
{cajero:'Ismael Gonzalez',maquina:8, producto:'calcetines'},
{cajero:'Marco Rostagno',maquina:9, producto:'cinturones'},
{cajero:'Kiko Caballero',maquina:10, producto:'carteras'},

  


]);

db.ventas.find()