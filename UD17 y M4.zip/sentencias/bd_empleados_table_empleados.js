use bd_empleados

db.empleados.insertMany([



{nombre:'Jorge',apellido:'Alvarez',departamento:'A'},
{nombre:'Anais',apellido:'Fernandez',departamento:'B'},
{nombre:'Raul',apellido:'Blas',departamento:'C'},
{nombre:'Alberto',apellido:'Conte',departamento:'D'},
{nombre:'Oscar',apellido:'Montes',departamento:'E'},
{nombre:'Daniel',apellido:'Nuvo',departamento:'F'},
{nombre:'David',apellido:'Mesa',departamento:'G'},
{nombre:'Asuncion',apellido:'Cardenas',departamento:'H'},
{nombre:'Carlos',apellido:'Zambrano',departamento:'I'},
{nombre:'Hector',apellido:'Zulia',departamento:'J'}
   

]);

db.empleados.find()