use bd_piezas_proveedores

db.suministra.insertMany([


{_id:1,ID_Proveedor:0001,precio:10},
{_id:2,ID_Proveedor:0001,precio:20},
{_id:3,ID_Proveedor:0001,precio:30},
{_id:4,ID_Proveedor:0001,precio:10},
{_id:5,ID_Proveedor:0001,precio:20},
{_id:6,ID_Proveedor:0001,precio:30},
{_id:7,ID_Proveedor:0002,precio:50},
{_id:8,ID_Proveedor:0002,precio:75},
{_id:9,ID_Proveedor:0009,precio:100},
{_id:10,ID_Proveedor:0010,precio:115}

]);

db.suministra.find()