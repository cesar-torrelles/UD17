use bd_directores

db.directores.insertMany([

{_id:'48653178',nomApels: 'Alba Alonso',despacho: 10},
{_id:'12345678',nomApels: 'Benito Buenafuente',despacho: 15},
{_id:'78974565',nomApels: 'Cecilia Castro',despacho: 10},
{_id:'98765432',nomApels:'Diego Devito',despacho: 20},
{_id:'10236211',nomApels: 'Enrique Egarritxea',despacho: 25},
{_id:'46548632',nomApels:'Francisca Fernandez',despacho: 30},
{_id:'89798535',nomApels:'Gemma Gallego',despacho: 35},
{_id:'41564684',omApels:'Hector Hernandez',despacho: 40},
{_id:'35454882',nomApels:'Indira Iovaisha',despacho: 45},
{_id:'54521201',nomApels:'Jacinto Jaramillo',despacho: 55}

]);

db.directores.find()