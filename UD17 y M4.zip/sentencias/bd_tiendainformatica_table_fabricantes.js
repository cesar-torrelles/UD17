use bd_tiendainformatica

db.fabricantes.insertMany([



{nombre:'intel'},
{nombre:'AMD'},
{nombre:'logitech'},
{nombre:'Xiaomi'},
{nombre:'Apple'},
{nombre:'Microsoft'},
{nombre:'Huawei'},
{nombre:'Samsung'},
{nombre:'Panasonic'},
{nombre:'Sony'}
   

]);

db.fabricantes.find()