use bd_almacenes

db.almacenes.insertMany([


{lugar:'España',capacidad: '20'},
{lugar:'Francia',capacidad: '30'},
{lugar:'Alemania',capacidad: '20'},
{lugar:'Suiza',capacidad: '50'},
{lugar:'Italia',capacidad: '10'},
{lugar:'Grecia',capacidad: '20'},
{lugar:'Inglaterra',capacidad: '70'},
{lugar:'Portugal',capacidad: '80'},
{lugar:'Polonia',capacidad: '90'},
{lugar:'Ukrania',capacidad: '100'},


]);

db.almacenes.find()