
use bd_directores

db.despachos.insertMany([

{_id:15,numero:15, capacidad: 50 },
{_id:20,numero:20, capacidad: 100 },
{_id:25,numero:25, capacidad: 150 },
{_id:30,numero:30, capacidad: 100 },
{_id:35,numero:35, capacidad: 70 },
{_id:40,numero:40, capacidad: 55 },
{_id:45,numero:45, capacidad: 90 },
{_id:50,numero:50, capacidad: 100 },
{_id:55,numero:55, capacidad: 210 }

]);

db.despachos.find()