use bd_tiendainformatica

db.articulos.insertMany([



{nombre:'teclado',precio: 34,fabricante: 'intel'},
{nombre:'raton',precio: 14,fabricante:'AMD'},
{nombre:'pantalla',precio: 250,fabricante:'logitech'},
{nombre:'camara',precio: 100, fabricante:'xiaomi'},
{nombre:'ram',precio: 50, fabricante:'Apple'},
{nombre:'placa' ,precio: 100, fabricante:'Microsoft'},
{nombre:'cable usb 2m',precio: 10, fabricante:'huawai'},
{nombre:'cable usb 5m',precio: 12, fabricante:'Samsung'},
{nombre:'disco duro',precio: 70, fabricante:'Panasonic'},
{nombre:'fuente de alimentacion',precio: 300, fabricante:'Sony'}
   

]);

db.articulos.find()