use bd_grandes_almacenes

db.maquinas.insertMany([

{piso:1),
   {piso:2},
    {piso:3},
    {piso:4},
    {piso:5},
    {piso:6},
    {piso:7},
    {piso:8},
    {piso:9},
    {piso:10}


]);

db.maquinas.find()