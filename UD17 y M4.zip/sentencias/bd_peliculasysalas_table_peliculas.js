use bd_peliculasysalas

db.peliculas.insertMany([


{nombre:'los juegos del hambre',calificacionEdad: '+18'},
{nombre:'la lista de schlinder',calificacionEdad: '+18'},
{nombre:'los miserables',calificacionEdad: '+13'},
{nombre:'torrente 2',calificacionEdad: '+16'},
{nombre:'Django',calificacionEdad: '+18'},
{nombre:'Matrix',calificacionEdad: '+13'},
{nombre:'la vida de PI',calificacionEdad: '+13'},
{nombre:'la guerra de los mundos',calificacionEdad: '+16'},
{nombre:'tadeo jones',calificacionEdad: 'todas las edades'},
{nombre:'iron man',calificacionEdad: '+13'}

]);

db.peliculas.find()