use bd_cientificos

db.proyecto.insertMany([

{_id:'0001',nombre: 'Proyecto A',horas: 50},
{_id:'0002',nombre: 'Proyecto A beta',horas: 70},
{_id:'0003',nombre: 'Proyecto B',horas: 55},
{_id:'0004',nombre: 'Proyecto C',horas: 46},
{_id:'0005',nombre: 'Proyecto D',horas: 48},
{_id:'0006',nombre: 'Proyecto E',horas: 36},
{_id:'0007',nombre: 'Proyecto F',horas: 87},
{_id:'0008',nombre: 'Proyecto G',horas: 23},
{_id:'0009',nombre: 'Proyecto H',horas: 53},
{_id:'0010',nombre: 'Proyecto I',horas: 68}

]);

db.proyecto.find()