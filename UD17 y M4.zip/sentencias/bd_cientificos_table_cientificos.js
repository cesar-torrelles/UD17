use bd_cientificos

db.cientifico.insertMany([


{_id:'12345670',nomApels: 'Juan José Gonzalez'},
{_id:'45362415',nomApels: 'Enric Carpio'},
{_id:'87965820',nomApels: 'June Orozco'},
{_id:'46225178',nomApels: 'Nerea Iglesias'},
{_id:'45648012',nomApels: 'Maria Concepcion Muriel'},
{_id:'74189245',nomApels: 'Marti García'},
{_id:'48663415',nomApels: 'Driss Calderon'},
{_id:'48776011',nomApels: 'Cintia Pinilla'},
{_id:'47878965',nomApels: 'Carlos Antonio Jimenez'},
{_id:'44852148',nomApels: 'Anselmo Andrade'}


]);

db.cientifico.find()