use bd_peliculasysalas

db.salas.insertMany([


{pelicula:'los juegos del hambre',sala: '1'},
{pelicula:'la lista de schlinder',sala: '2'},
{pelicula:'los miserables',sala: '3'},
{pelicula:'torrente 2',sala: '4'},
{pelicula:'Django',sala: '5'},
{pelicula:'Matrix',sala: '6'},
{pelicula:'la vida de PI',sala: '7'},
{pelicula:'la guerra de los mundos',sala: '8'},
{pelicula:'tadeo jones',sala: '9'},
{pelicula:'iron man',sala: '10'}


]);

db.salas.find()