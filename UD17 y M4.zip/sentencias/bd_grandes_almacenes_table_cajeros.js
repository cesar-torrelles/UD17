use bd_grandes_almacenes

db.cajeros.insertMany([


{nomApels:'Alberto Zambrano'},
   {nomApels:'Luis Perez'},
    {nomApels:'Ana Fernandez'},
    {nomApels:'Raul Farfan'},
    {nomApels:'Jose Lito'},
    {nomApels:'Carlos Latre'},
    {nomApels:'Kimberly Alvarez'},
    {nomApels:'Ismael Gonzalez'},
    {nomApels:'Marco Rostagno'},
    {nomApels:'Kiko Caballero'}


]);

db.cajeros.find()