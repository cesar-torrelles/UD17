use bd_almacenes

db.cajas.insertMany([


{contenido:'5',valor:'100',almacen:'España'},
{contenido:'4',valor:'100',almacen:'Francia'},
{contenido:'3',valor:'100',almacen:'Alemania'},
{contenido:'15',valor:'100',almacen:'Suiza'},
{contenido:'30',valor:'100',almacen:'Italia'},
{contenido:'10',valor:'100',almacen:'Grecia'},
{contenido:'18',valor:'100',almacen:'Inglaterra'},
{contenido:'23',valor:'100',almacen:'Portugal'},
{contenido:'45',valor:'100',almacen:'Polonia'},
{contenido:'89',valor:'100',almacen:'Ukrania'},

]);

db.cajas.find()