use bd_investigadores

db.facultad.insertMany([


{_id:1,nombre: 'Facultad de Agronomía'},
{_id:2,nombre: 'Facultad de Arquitectura'},
{_id:3,nombre: 'Facultad de Ciencias de la Educación'},
{_id:4,nombre: 'Facultad de Ciencias Económicas'},
{_id:5,nombre: 'Facultad de Química'},
{_id:6,nombre: 'Facultad de Ciencias Sociales'},
{_id:7,nombre: 'Facultad de Derecho'},
{_id:8,nombre: 'Facultad de Educación Física'},
{_id:9,nombre: 'Facultad de Filosofía'},
{_id:10,nombre: 'Facultad de Humanidades'}


]);

db.facultad.find()