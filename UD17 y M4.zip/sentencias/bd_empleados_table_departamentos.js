use bd_empleados

db.departamentos.insertMany([



{nombre:'A',presupuesto: 3300},
{nombre:'B',presupuesto: 4500},
{nombre:'C',presupuesto: 1500},
{nombre:'D',presupuesto: 15000},
{nombre:'E',presupuesto: 20000},
{nombre:'F',presupuesto: 30000},
{nombre:'G',presupuesto: 10000},
{nombre:'H',presupuesto: 3240},
{nombre:'I',presupuesto: 5600},
{nombre:'J',presupuesto: 7000}


]);

db.departamentos.find()