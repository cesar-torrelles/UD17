use bd_investigadores

db.equipos.insertMany([

{_id:'0001',nombre: 'Equipo1',facultad: 2},
{_id:'0002',nombre: 'Equipo2',facultad: 6},
{_id:'0003',nombre: 'Equipo3',facultad: 2},
{_id:'0004',nombre: 'Equipo4',facultad: 7},
{_id:'0005',nombre: 'Equipo5',facultad: 3},
{_id:'0006',nombre: 'Equipo6',facultad: 1},
{_id:'0007',nombre: 'Equipo7',facultad: 9},
{_id:'0008',nombre: 'Equipo8',facultad: 4},
{_id:'0009',nombre: 'Equipo9',facultad: 10},
{_id:'0010',nombre: 'Equipo10',facultad: 1}

]);

db.equipos.find()