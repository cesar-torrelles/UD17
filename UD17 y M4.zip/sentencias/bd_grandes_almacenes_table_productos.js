use bd_grandes_almacenes

db.productos.insertMany([



{nombre:'carteras',precio: 15},
    {nombre:'zapatos',precio: 45},
    {nombre:'camisetas',precio:15},
    {nombre:'pantalones',precio:25},
    {nombre:'gorras',precio:35},
    {nombre:'chanclas',precio:15},
    {nombre:'collares',precio:50},
    {nombre:'gafas',precio:53},
    {nombre:'calcetines',precio:12},
    {nombre:'cinturones',precio:14}


]);

db.productos.find()