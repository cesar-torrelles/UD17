use bd_piezas_proveedores

db.piezas.insertMany([


	{_id:1,nombre:"tornillo pequeño"},
    {_id:2,nombre:"tornillo mediano"},
    {_id:3,nombre:"tornillo grande"},
    {_id:4,nombre:"tuerca pequeña"},
    {_id:5,nombre:"tuerca mediana"},
    {_id:6,nombre:"tuerca grande"},
    {_id:7,nombre:"rueda dentada pequeña"},
    {_id:8,nombre:"rueda dentada mediana"},
    {_id:9,nombre:"rueda dentada grande"},
    {_id:10,nombre:"correa pequeña"}

]);

db.piezas.find()